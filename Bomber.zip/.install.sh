apt update & apt upgrade -y
pip3 install phonenumbers
pip3 install requests
rm .install.sh
clear
python Bomber.py
